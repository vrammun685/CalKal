import React from 'react';

export default function Loading() {
  return <div>Cargando...</div>;
}